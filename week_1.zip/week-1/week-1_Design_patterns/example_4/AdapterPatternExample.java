public class AdapterPatternExample {
    public static void main(String[] args) {
        // Using PayPal gateway through adapter
        PaypalGateway paypalGateway = new PaypalGateway();
        PaymentProcessor paypalProcessor = new PaypalAdapter(paypalGateway);
        paypalProcessor.processPayment(100.0);

        // Using Stripe gateway through adapter
        StripeGateway stripeGateway = new StripeGateway();
        PaymentProcessor stripeProcessor = new StripeAdapter(stripeGateway);
        stripeProcessor.processPayment(200.0);

        // Using Square gateway through adapter
        SquareGateway squareGateway = new SquareGateway();
        PaymentProcessor squareProcessor = new SquareAdapter(squareGateway);
        squareProcessor.processPayment(300.0);
    }
}