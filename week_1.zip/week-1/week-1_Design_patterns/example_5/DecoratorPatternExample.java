public class DecoratorPatternExample {
    public static void main(String[] args) {
        // Send email notification
        Notifier emailNotifier = new EmailNotifier();
        emailNotifier.send("Hello via Email!");

        // Send email and SMS notification
        Notifier smsNotifier = new SMSNotifierDecorator(new EmailNotifier());
        smsNotifier.send("Hello via Email and SMS!");

        // Send email, SMS, and Slack notification
        Notifier slackNotifier = new SlackNotifierDecorator(new SMSNotifierDecorator(new EmailNotifier()));
        slackNotifier.send("Hello via Email, SMS, and Slack!");
    }
}