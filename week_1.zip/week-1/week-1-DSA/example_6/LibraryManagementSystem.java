import java.util.Arrays;

public class LibraryManagementSystem {
    public static void main(String[] args) {
        Book[] books = {
            new Book("B001", "Java Programming", "James Gosling"),
            new Book("B002", "Python Essentials", "Guido van Rossum"),
            new Book("B003", "Data Structures", "Mark Allen Weiss"),
            new Book("B004", "Artificial Intelligence", "Stuart Russell"),
            new Book("B005", "Machine Learning", "Tom Mitchell")
        };

        // Sort books by title for binary search
        Arrays.sort(books, (b1, b2) -> b1.title.compareToIgnoreCase(b2.title));

        Library library = new Library(books);

        // Linear search
        System.out.println("Linear Search: Searching for 'Python Essentials'");
        Book foundBook = library.linearSearchByTitle("Python Essentials");
        System.out.println(foundBook != null ? foundBook : "Book not found");

        // Binary search
        System.out.println("\nBinary Search: Searching for 'Artificial Intelligence'");
        foundBook = library.binarySearchByTitle("Artificial Intelligence");
        System.out.println(foundBook != null ? foundBook : "Book not found");
    }
}
