import java.util.ArrayList;

class EmployeeManager {
    private ArrayList<Employee> employees;

    public EmployeeManager() {
        employees = new ArrayList<>();
    }

    // Add a new employee
    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    // Update an existing employee's details
    public boolean updateEmployee(String employeeId, String department, String position, double salary) {
        for (Employee employee : employees) {
            if (employee.getEmployeeId().equals(employeeId)) {
                employee.setDepartment(department);
                employee.setPosition(position);
                employee.setSalary(salary);
                return true;
            }
        }
        return false; // Employee not found
    }

    // Delete an employee record
    public boolean deleteEmployee(String employeeId) {
        return employees.removeIf(employee -> employee.getEmployeeId().equals(employeeId));
    }

    // Retrieve employee information
    public Employee getEmployee(String employeeId) {
        for (Employee employee : employees) {
            if (employee.getEmployeeId().equals(employeeId)) {
                return employee;
            }
        }
        return null; // Employee not found
    }

    // List all employees
    public void listAllEmployees() {
        for (Employee employee : employees) {
            System.out.println(employee);
        }
    }
}
